export type TLoadingStatus = 'loading' | 'ok' | 'error'
