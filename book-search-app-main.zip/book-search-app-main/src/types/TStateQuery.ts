export type TStateQuery = {
  startIndex: number,
  baseQuery: string,
}
