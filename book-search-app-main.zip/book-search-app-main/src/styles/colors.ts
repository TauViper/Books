export const colors: string = `
  html {
    --color-main: #ddd;
    --color-second: #222;
    --color-fade: #444;
    --color-accent: #88e;
    --color-accent-second: #44a;
  }
`
